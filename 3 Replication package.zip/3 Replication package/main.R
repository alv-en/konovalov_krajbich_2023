# set the working directory
setwd("~/Drive/RESEARCH/Strategic_RTs/docs/ACCEPTANCE/3 Replication package")

# script by Arkady Konovalov (arkady.konovalov@gmail.com)

# install required packages
install.packages(c("multiwayvcov", "sciplot","texreg","lmtest", "dplyr", "viridis"))

rm(list = ls())
library(multiwayvcov)
library(sciplot)
library(texreg)
library(lmtest)
library(dplyr)
library(viridis)
source('myfunctions.R')

##############################################
# MAIN TEXT
##############################################

### IN-TEXT NUMBERS

# footnote 24 (section  4.2)
load('data/bargaining1.RData')
data = fdata2
ps = c()
coefs = c()
ids = unique(data$Subject)
for (i in 1:length(unique(data$Subject))){
  temp = filter(data,Subject == ids[i])
  b = summary(lm(price2 ~ rt + price1,temp))
  ps[i] = b$coefficients[2,4]
  coefs[i] = b$coefficients[2,1]
  print(nrow(temp))
} 
n1 = sum(coefs>0 ) # 57/66
n2 = sum(coefs>0 & ps < 0.1 ) # 44/57

txt1 = sprintf("In the Explicit-RT experiment, %d/66 subjects exhibited a positive relationship between RT and second price (controlling for first price), and this was significant for %d/%d at p < 0.1 (with only 20 observations per subject); none of the negative coefficients were significant.", n1, n2 ,n1)

# RESULT 5 (section  4.3)
load('data/bargaining2.RData')
price1t = tapply(fdatas$price1,list(fdatas$condition,fdatas$Subject),mean,na.rm = T)
price1 = round(rowMeans(price1t,na.rm = T),1)
se_price1 = round(apply(price1t,1,se),1)
n1 = round(mean(price1t[2,],na.rm = T),1)
n2 = round(mean(price1t[4,],na.rm = T),1)
n3 = round(mean(price1t[1,],na.rm = T),1)
n4 = round(mean(price1t[3,],na.rm = T),1)
n5 = round(wilcox.test(price1t[2,],price1t[4,])$p.value,2) # p = 0.06
n6 = round(wilcox.test(price1t[1,],price1t[3,])$p.value,2) # p = 0.52

txt2 = sprintf("In the second half of the Live experiment, comparing treatments, sellers’ first offers were significantly higher in Visible compared to Hidden bargaining (Table B1, %g vs. %g, p = %g, Wilcoxon rank sum test at the subject level).", n1, n2 ,n5)

txt3 = sprintf("We found no such difference in first offers in the first half of the Live experiment (%g vs %g, p = %g, Wilcoxon rank sum test at the subject level).", n3, n4 ,n6)

# footnote 25 (section  4.4)
load('data/bargaining2.RData')
price2t = tapply(fdatas[fdatas$accept1==0,]$price2,list(fdatas[fdatas$accept1==0,]$condition,fdatas[fdatas$accept1==0,]$Subject),mean,na.rm = T)
price2 = round(rowMeans(price2t,na.rm = T),1)
se_price2 = round(apply(price2t,1,se),1)
n1 = round(wilcox.test(price2t[1,],price2t[3,])$p.value,2) # p = 0.23
n2 = round(wilcox.test(price2t[2,],price2t[4,])$p.value,2) # p = 0.15
txt4 = sprintf("When considering the second stage, there were again no differences in terms of second-stage offers (p = %g), or second-stage acceptance rates (p = %g).", n2, n1)

# RESULT 8 (section  4.5)
# "Specifically, in the Explicit-RT experiment, ... "
load('data/bargaining1.RData')
data2 = fdata2
datas = fdatas

sellers = unique(fdatas[fdatas$type==1,]$Subject)
buyers = unique(fdata[fdata$type==2,]$Subject)

temp = data2[data2$Subject %in% sellers,]
profitsellers2 =  0.8*tapply(temp$Profit,temp$Subject,mean)

temp = data2[data2$Subject %in% buyers,]
profitbuyers2 =  0.8*tapply(temp$Profit,temp$Subject,mean)
profitpart2 = c(profitsellers2,profitbuyers2)

profitsellers1 = tapply(datas[datas$accept1 == 0,]$Profit,datas[datas$accept1 == 0,]$Subject,mean)
idx = !(datas$value>datas$price2 & datas$accept2 == 0 & datas$accept1 == 0)
profitsellers1a = tapply(datas[datas$accept1 == 0 & idx,]$Profit,datas[datas$accept1 == 0 & idx,]$Subject,mean)

wilcox.test(profitsellers1a,profitsellers2, paired = T)
sum(profitsellers2>profitsellers1a)

n1 = round(mean(profitpart2),1) # 14.1 ECU
n2 = round(mean(profitsellers1a),1) # 11.6 ECU 
n3 = round(wilcox.test(profitpart2,profitsellers1a)$p.value,3) # p = 0.003

txt5 = sprintf("In the Explicit-RT experiment, sellers earned more in the Hidden Selling task, where they had access to buyers’ RT, than in the Hidden Bargaining task, where they did not (p = %g). Specifically, in the Explicit-RT experiment, sellers in the bargaining game earned %g ECU on average (conditional on rejection and excluding a small number of trials where subjects rejected positive-profit offers in the second stage), and subjects in the selling task earned %g ECU on average (the difference is significant at p = %g, Wilcoxon rank-sum test at the subject level)", n3, n2, n1 , n3 )

# "In the first half of the Live experiment,..." (section  4.5)
load('data/bargaining2.RData')

fdata2 = fdata24[fdata24$part == 1,]
fdata4 = fdata24[fdata24$part == 0,]
fdata2 = fdata2[fdata2$reps==0,]
fdata4 = fdata4[fdata4$reps==0,]

datas = fdatas[fdatas$part==1 & fdatas$visible == 0,]
sellers = unique(fdatas[fdatas$type==1,]$Subject)
buyers = unique(fdata[fdata$type==2,]$Subject)

data2 = fdata2[fdata2$visible == 0,]

temp = data2[data2$Subject %in% sellers,]
profitsellers2 =  0.8*tapply(temp$Profit,temp$Subject,mean)

profitsellers1 = tapply(datas[datas$accept1 == 0,]$Profit,datas[datas$accept1 == 0,]$Subject,mean)
idx = !(datas$value>datas$price2 & datas$accept2 == 0 & datas$accept1 == 0)
profitsellers1a = tapply(datas[datas$accept1 == 0 & idx,]$Profit,datas[datas$accept1 == 0 & idx,]$Subject,mean)

n1 = round(mean(profitsellers2),2) # 12.05 ECU
n2 = round(mean(profitsellers1a),1) # 12.2 ECU
n3 = round(wilcox.test(profitsellers2,profitsellers1a,pairwise = T)$p.value, 2) # p = 0.98

txt6 = sprintf("In the first half of the Live experiment, sellers earned the same amount in bargaining H and selling H tasks (%g vs %g ECU, p = %g, Wilcoxon rank-sum test at the subject level).", n1, n2, n3)


# "In the second half of the Live experiment,..." (section  4.5)

load('data/bargaining2.RData')

sellers = unique(fdatas[fdatas$type==1,]$Subject)
fdata4 = fdata24[fdata24$part == 0,]
fdata2 = fdata2[fdata2$reps==0,]
fdata4 = fdata4[fdata4$reps==0,]

data4 = fdata4[fdata4$visible == 0,]
temp = data4[data4$Subject %in% sellers,]
profitsellers4 =  0.8*tapply(temp$Profit,temp$Subject,mean)

datas = fdatas[fdatas$part==0 & fdatas$visible == 0,]
profitsellers3 = tapply(datas[datas$accept1 == 0,]$Profit,datas[datas$accept1 == 0,]$Subject,mean)
idx = !(datas$value>datas$price2 & datas$accept2 == 0 & datas$accept1 == 0)
profitsellers3a = tapply(datas[datas$accept1 == 0 & idx,]$Profit,datas[datas$accept1 == 0 & idx,]$Subject,mean)

n1 = round(mean(profitsellers4),1) # 11.3 ECU
n2 = round(mean(profitsellers3a),1) # 11.2 ECU
n3 = round(wilcox.test(profitsellers4,profitsellers3a,pairwise = T)$p.value,2) # p = 0.85

txt7 = sprintf("In the second half of the Live experiment, sellers earned %g ECU in the H selling task and %g ECU in the H bargaining task (however, the difference was not statistically significant: p = %g, Wilcoxon rank-sum test at the subject level).", n1, n2, n3)


# RESULT 9 (section  4.5)
load('data/bargaining2.RData')
profit_bt = tapply(fdata$Profit,list(fdata$condition,fdata$Subject),mean,na.rm = T)
profit_b = round(rowMeans(profit_bt,na.rm = T),1)
se_profit_b = round(apply(profit_bt,1,se),1)

n1 = round(mean(profit_bt[2,], na.rm = T),1) # 18.4 ECU
n2 = round(mean(profit_bt[4,], na.rm = T),1) # 21.1 ECU
n3 = round(wilcox.test(profit_bt[2,],profit_bt[4,])$p.value,1) # p = 0.1

profit_st_rej = tapply(fdatas[fdatas$accept1==0,]$Profit,list(fdatas[fdatas$accept1==0,]$condition,fdatas[fdatas$accept1==0,]$Subject),mean,na.rm = T)
profit_s_rej = round(rowMeans(profit_st_rej,na.rm = T),1)
se_profit_s_rej = round(apply(profit_st_rej,1,se),1)

n4 = round(mean(profit_st_rej[2,], na.rm = T),1) # 13.7 ECU
n5 = round(mean(profit_st_rej[4,], na.rm = T),1) # 10.7 ECU
n6 = round(wilcox.test(profit_st_rej[2,],profit_st_rej[4,])$p.value,2) # p = 0.01

txt8 = sprintf("In the second half of the Live experiment, compared to Hidden, in Visible bargaining buyers earned less (%g vs. %g, p = %g, Wilcoxon rank sum test at the subject level) and sellers significantly more, conditional on rejection, (Table B1, %g vs. %g, p = %g, Wilcoxon rank sum test at the subject level).", n2, n1, n3, n4, n5, n6)

# "Surprisingly, we observed the opposite result.. " (section 4.5)
load('data/bargaining2.RData')

fdata2 = fdata24[fdata24$part == 1,]
fdata4 = fdata24[fdata24$part == 0,]

fdata2 = fdata2[fdata2$reps==0,]
fdata4 = fdata4[fdata4$reps==0,]

hdata4 = fdata4[fdata4$visible == 0,]
vdata4 = fdata4[fdata4$visible == 1,]

hprofits = tapply(hdata4$Profit,hdata4$Subject,mean,na.rm = T)
vprofits = tapply(vdata4$Profit,vdata4$Subject,mean,na.rm = T)

n1 = round(mean(hprofits),1) # 15 ECU
n2 = round(mean(vprofits),1) # 19.7 ECU
n3 = round(wilcox.test(hprofits,vprofits,pairwise = F)$p.value) # p < 0.001

txt9 = sprintf("Surprisingly, we observed the opposite result in the second iteration of the selling task: sellers earned more in the V treatment (%g ECU) than in the H treatment (%g ECU; p < 0.001).", n2, n1)

# footnote 26 (section 4.5)
load('data/bargaining1.RData')
data2 = fdata2

sellers = unique(fdatas[fdatas$type==1,]$Subject)
buyers = unique(fdata[fdata$type==2,]$Subject)

temp = data2[data2$Subject %in% sellers,]
profitsellers2 =  0.8*tapply(temp$Profit,temp$Subject,mean)

temp = data2[data2$Subject %in% buyers,]
profitbuyers2 =  0.8*tapply(temp$Profit,temp$Subject,mean)

n1 = round(mean(profitbuyers2),1)
n2 = round(mean(profitsellers2),1)
n3 = round(wilcox.test(profitbuyers2,profitsellers2)$p.value,2) 

txt10 = sprintf("Former buyers earned more than former sellers (%g vs %g), but this difference was not statistically significant (p = %g, Wilcoxon rank-sum test at the subject level).", n1, n2, n3)

# footnote 29 (section 6)
load('data/bargaining2.RData')
data = fdata[fdata$part == 1,]

mean(data$price1)
data$eprice2 = fitted(lm(price2~price1,data))

data$ev_accept = data$value - data$price1
data$ev_reject = 0.8*(data$value - data$eprice2)

data$surplus.chosen = data$accept1*data$ev_accept + (1-data$accept1)*data$ev_reject
data$surplus.unchosen = (1-data$accept1)*data$ev_accept + (data$accept1)*data$ev_reject

xpos = tapply(data[data$surplus.chosen - data$surplus.unchosen>0,]$rt1,data[data$surplus.chosen - data$surplus.unchosen>0,]$Subject,mean,na.rm = T)
xneg = tapply(data[data$surplus.chosen - data$surplus.unchosen<0,]$rt1,data[data$surplus.chosen - data$surplus.unchosen<0,]$Subject,mean, na.rm = T)

tt = t.test(xpos,xneg) # 3.95, 4.86, p < 0.001
n1 = round(tt$estimate[1],2)
n2 = round(tt$estimate[2],2)
n3 = round(tt$p.value,2)

txt11 = sprintf("We found that RTs were 0.91 seconds longer in “error” trials, where an option with lower expected surplus was chosen (%g s vs %g s, p < 0.001, paired t-test at the subject level).", n2, n1)

# SECTION 4.6.

data = read.csv("data/raw/survey/bargain_survey.csv")

data2 = data[data$Q22=="Cookies and Cream",]
data3 = data2[((data2$Q7!="Never") | (data2$Q8!="Never")),]

amount=grepl("amount",data3$Q21)
n11 = sum(amount)
n1 = round(100*mean(amount))

time=grepl("time",data3$Q21)
n21 = sum(time)
n2 = round(100*mean(time))

words=grepl("words",data3$Q21)
n31 = sum(words)
n3 = round(100*mean(words))

user=grepl("user",data3$Q21)
n41 = sum(user)
n4 = round(100*mean(user))

body=grepl("body",data3$Q21)
n51 = sum(body)
n5 = round(100*mean(body))

emotion=grepl("emotion",data3$Q21)
n61 = sum(emotion)
n6 = round(100*mean(emotion))

demo=grepl("demo",data3$Q21)
n71 = sum(demo)
n7 = round(100*mean(demo))


txt12 = sprintf("Our key question asked: ‘If you bargain, what do you pay attention to when bargaining? (Select all that apply)’.  The most common answer was ‘the amount of the offer’ (n = %g, %g%%). However, the next most common answer was ‘the time it takes the other person to respond to your offers’ (n = %g, %g%%).", n11, n1, n21, n2)

txt13 = sprintf("Other answers included “the specific words of phrases used by the other person” (n = %g, %g%%), “the other person’s user ratings or profile” (n = %g, %g%%), “the other person’s facial expressions or body language” (n = %g, %g%%), “the other person’s emotional state” (n = %g, %g%%), and “the other person’s demographics” (n = %g, %g%%).", n31, n3, n41, n4, n51, n5, n61, n6, n71, n7)

## FIGURE 1

# a
load('data/bargaining2.RData')
data = fdata 
data$surplus = data$value - data$price1
cplot(data$surplus,data$rt1,cluster = data$Subject, group = data$accept1, group.rev = T, cex.lab = 1.1,
      cutoff = 10, bins = 5, ceil = T, labels = c('first offer accepted','first offer rejected'), legend = T, shift = 1,
      xlab = "buyer's surplus", ylab = 'RT [s]',width=5, height=4, color = c(cs[5],cs[1]),
      ylim = c(2,7), pdf.name = 'output/figures/figure1a.pdf')

# b
load('data/bargaining1.RData')
data = fdata 
data$surplus = data$value - data$price1
cplot(data$surplus,data$rt1,cluster = data$Subject, group = data$accept1, group.rev = T, cex.lab = 1.1,
      cutoff = 10, bins = 5, ceil = T, labels = c('first offer accepted','first offer rejected'), legend = T, shift = 1,
      xlab = "buyer's surplus", ylab = 'RT [s]',width=5, height=4, color = c(cs[5],cs[1]),
      ylim = c(3,8), pdf.name = 'output/figures/figure1b.pdf')

## FIGURE 2

# a
load('data/bargaining1.RData')
data = fdata2
cplot(data$rt,data$price2,cluster = data$Subject,
      bins = 1, color = cs[1],cutoff = 10, pch = 18,
      xlab = 'RT [s]', ylab = 'new offer',maxbin =8,
      ylim = c(20,45))
data = fdatas[fdatas$accept1 == 0,]
cplot(data$rtb,data$price2,cluster = data$Subject, pch = 16, shift = 0.1,
      bins = 1, cutoff = 10, add = T, color = cs[5])
legend('topleft',legend = c('Selling 1H (explicit)','Bargaining 1H (explicit)'), pch = c(18,16),col = c(cs[1],cs[5]),cex = 1,bty = 'n')
dev.copy2pdf(file = paste("output/figures/figure2a.pdf",sep = ''),width=5, height=4) 

# b
load('data/bargaining2.RData')
data = fdatas[fdatas$accept1==0 & fdatas$part == 0 & fdatas$visible==0,]
cplot(data$rtb,data$price2, bins = 1, cluster = data$Subject, 
      cutoff = 10, color = cs[5], ylim = c(20,50), 
      ylab = 'new offer', xlab = 'RT[s]')
data = fdatas[fdatas$accept1==0 & fdatas$part == 0 & fdatas$visible==1,]
cplot(data$rtb,data$price2, bins = 1, cluster = data$Subject, pch = 18,
      cutoff = 10, color = cs[1], add = T, lty = 2)
legend("topleft",legend = c('Bargaining 2H (live)','Bargaining 2V (live)'), pch = c(18,16),
       col = c(cs[5],cs[1]),bty = 'n')
dev.copy2pdf(file = paste("output/figures/figure2b.pdf",sep = ''),width=5, height=4) 


# c
load('data/bargaining2.RData')
data = fdata24[fdata24$part == 1 & fdata24$visible==0,]
cplot(data$rt,data$price2, bins = 1.5, cluster = data$Subject, 
      cutoff = 15, color = cs[5], ylim = c(25,45), 
      ylab = 'new offer', xlab = 'RT[s]')
data = fdata24[fdata24$part == 1 & fdata24$visible==1,]
cplot(data$rt,data$price2, bins = 1.5, cluster = data$Subject, pch = 18,
      cutoff = 15, color = cs[1], add = T, lty = 2)
legend("topleft",legend = c('Selling 1H (live)','Selling 1V (live)'), pch = c(18,16), 
       col = c(cs[5],cs[1]),bty = 'n')
dev.copy2pdf(file = paste("output/figures/figure2c.pdf",sep = ''),width=5, height=4) 


# d
load('data/bargaining2.RData')
data = fdata24[fdata24$part == 0 & fdata24$visible==0,]
cplot(data$rt,data$price2, bins = 1.5, cluster = data$Subject, 
      cutoff = 15, color = cs[5], ylim = c(25,45), 
      ylab = 'new offer', xlab = 'RT[s]')
data = fdata24[fdata24$part == 0 & fdata24$visible==1,]
cplot(data$rt,data$price2, bins = 1.5, cluster = data$Subject, pch = 18,
      cutoff = 15, color = cs[1], add = T, lty = 2)
legend("topleft",legend = c('Selling 2H (live)','Selling 2V (live)'), pch = c(18,16), 
       col = c(cs[5],cs[1]),bty = 'n')
dev.copy2pdf(file = paste("output/figures/figure2d.pdf",sep = ''),width=5, height=4) 


##############################################
# APPENDIX A
##############################################

# FIGURE A1
load('data/bargaining2.RData')

# a
data = fdatas[fdatas$condition ==1 |  fdatas$condition == 3,]
cplot(data$Period,data$price1, cluster = data$Subject, group = data$condition,
      ylim = c(10,60), labels = c('Bargaining 1H','Bargaining 1V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'first offer',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA1a.pdf', width=3.6, height=3.4)

# b
data = fdatas[fdatas$condition ==1 |  fdatas$condition == 3,]
data = data[data$accept1 == 0,]
cplot(data$Period,data$price2, cluster = data$Subject, group = data$condition,
      ylim = c(10,60), labels = c('Bargaining 1H','Bargaining 1V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'second offer',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA1b.pdf', width=3.6, height=3.4)

# c
data = fdatas[fdatas$condition ==1 |  fdatas$condition == 3,]
cplot(data$Period,data$accept1, cluster = data$Subject, group = data$condition,
      ylim = c(0,1), labels = c('Bargaining 1H','Bargaining 1V'), legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'P (first accepted)',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA1c.pdf', width=3.6, height=3.4)

# d
data = fdatas[fdatas$condition ==1 |  fdatas$condition == 3,]
data = data[data$accept1 == 0,]
cplot(data$Period,data$accept2, cluster = data$Subject, group = data$condition,
      ylim = c(0,1), labels = c('Bargaining 1H','Bargaining 1V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'P (second accepted)',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA1d.pdf', width=3.6, height=3.4)

# e
data = fdata[fdata$condition ==1 |  fdata$condition == 3,]
cplot(data$Period,data$Profit, cluster = data$Subject, group = data$condition,
      ylim = c(0,50), labels = c('Bargaining 1H','Bargaining 1V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'buyers surplus',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA1e.pdf', width=3.6, height=3.4)

# f
data = fdatas[fdatas$condition ==1 |  fdatas$condition == 3,]
cplot(data$Period,data$Profit, cluster = data$Subject, group = data$condition,
      ylim = c(0,50), labels = c('Bargaining 1H','Bargaining 1V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'sellers profit',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA1f.pdf', width=3.6, height=3.4)


# FIGURE A2
load('data/bargaining2.RData')

# a
data = fdatas[fdatas$condition ==2 |  fdatas$condition == 4,]
cplot(data$Period,data$price1, cluster = data$Subject, group = data$condition, group.rev = T,
      ylim = c(10,60), labels = c('Bargaining 2H','Bargaining 2V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'first offer',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA2a.pdf', width=3.6, height=3.4)

# b
data = fdatas[fdatas$condition ==2 |  fdatas$condition == 4,]
data = data[data$accept1 == 0,]
cplot(data$Period,data$price2, cluster = data$Subject, group = data$condition, group.rev = T,
      ylim = c(10,60), labels = c('Bargaining 2H','Bargaining 2V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'second offer',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA2b.pdf', width=3.6, height=3.4)

# c
data = fdatas[fdatas$condition ==2 |  fdatas$condition == 4,]
cplot(data$Period,data$accept1, cluster = data$Subject, group = data$condition, group.rev = T,
      ylim = c(0,1), labels = c('Bargaining 2H','Bargaining 2V'), legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'P (first accepted)',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA2c.pdf', width=3.6, height=3.4)

# d
data = fdatas[fdatas$condition ==2 |  fdatas$condition == 4,]
data = data[data$accept1 == 0,]
cplot(data$Period,data$accept2, cluster = data$Subject, group = data$condition, group.rev = T,
      ylim = c(0,1), labels = c('Bargaining 2H','Bargaining 2V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'P (second accepted)',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA2d.pdf', width=3.6, height=3.4)

# e
data = fdata[fdata$condition ==2 |  fdata$condition == 4,]
cplot(data$Period,data$Profit, cluster = data$Subject, group = data$condition, group.rev = T,
      ylim = c(0,50), labels = c('Bargaining 2H','Bargaining 2V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'buyers surplus',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA2e.pdf', width=3.6, height=3.4)

# f
data = fdatas[fdatas$condition ==2 |  fdatas$condition == 4,]
cplot(data$Period,data$Profit, cluster = data$Subject, group = data$condition, group.rev = T,
      ylim = c(0,50), labels = c('Bargaining 2H','Bargaining 2V'), legend = T, legend.pos = 'bottomleft',
      xlab = 'period', ylab = 'sellers profit',
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA2f.pdf', width=3.6, height=3.4)


# FIGURE A3
load('data/bargaining2.RData')

# a
data = fdata24[fdata24$part == 1,]
cplot(data$Period,data$price2, cluster = data$Subject, group = data$visible,
      ylim = c(10,70),  legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'second offer',  labels = c('Selling 1H','Selling 1V'),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA3a.pdf', width=3.6, height=3.4)

# b
data = fdata24[fdata24$part == 1,]
cplot(data$Period,data$accept, cluster = data$Subject, group = data$visible,
      ylim = c(0,1),  legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'P (offer accepted)',  labels = c('Selling 1H','Selling 1V'),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA3b.pdf', width=3.6, height=3.4)

# c
data = fdata24[fdata24$part == 1,]
cplot(data$Period,data$Profit, cluster = data$Subject, group = data$visible,
      ylim = c(0,40),  legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'profit',  labels = c('Selling 1H','Selling 1V'),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA3c.pdf', width=3.6, height=3.4)


# FIGURE A4
load('data/bargaining2.RData')

# a
data = fdata24[fdata24$part == 0,]
cplot(data$Period,data$price2, cluster = data$Subject, group = data$visible,
      ylim = c(10,70),  legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'second offer',  labels = c('Selling 2H','Selling 2V'),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA4a.pdf', width=3.6, height=3.4)

# b
data = fdata24[fdata24$part == 0,]
cplot(data$Period,data$accept, cluster = data$Subject, group = data$visible,
      ylim = c(0,1),  legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'P (offer accepted)',  labels = c('Selling 2H','Selling 2V'),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA4b.pdf', width=3.6, height=3.4)

# c
data = fdata24[fdata24$part == 0,]
cplot(data$Period,data$Profit, cluster = data$Subject, group = data$visible,
      ylim = c(0,40),  legend = T, legend.pos = 'topleft',
      xlab = 'period', ylab = 'profit',  labels = c('Selling 2H','Selling 2V'),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA4c.pdf', width=3.6, height=3.4)

# FIGURE A5
load('data/bargaining1.RData')

# a
data = fdatas
cplot(data$Period,data$accept1, cluster = data$Subject,
      ylim = c(0,1),xlab = 'period', ylab = 'P (first accepted)', hline = mean(data$accept1),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA5a.pdf', width=3.6, height=3.4)

# b
data = fdatas
data = data[data$accept1 == 0,]
cplot(data$Period,data$accept2, cluster = data$Subject,
      ylim = c(0,1), xlab = 'period', ylab = 'P (second accepted)', hline = mean(data$accept2),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA5b.pdf', width=3.6, height=3.4)

# c
data = fdatas
cplot(data$Period,data$price1, cluster = data$Subject,
      ylim = c(10,70), xlab = 'period', ylab = 'first offer', hline = mean(data$price1),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA5с.pdf', width=3.6, height=3.4)

# d
data = fdatas
data = data[data$accept1 == 0,]
cplot(data$Period,data$price2, cluster = data$Subject,
      ylim = c(10,60), xlab = 'period', ylab = 'second offer', hline = mean(data$price2),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA5d.pdf', width=3.6, height=3.4)

# e
data = fdata
cplot(data$Period,data$Profit, cluster = data$Subject,
      ylim = c(0,50), xlab = 'period', ylab = 'buyers surplus', hline = mean(data$Profit),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA5e.pdf', width=3.6, height=3.4)

# f
data = fdatas
cplot(data$Period,data$Profit, cluster = data$Subject, 
      ylim = c(0,50), xlab = 'period', ylab = 'sellers profit', hline = mean(data$Profit),
      pch = 16, pch2 = 1, lwd = 2, pdf.name = 'output/figures/figureA5f.pdf', width=3.6, height=3.4)

# caption
load('data/bargaining1.RData')
data = fdatas
b1 = lm(price1 ~ Period,data = data) # first offer regression
clusters = cluster.vcov(b1, cbind(data$Subject))
b1c = coeftest(b1, clusters)
n1 = round(b1c[2,4],2) # p = 0.17
n2 = round(mean(data$price1[data$Period==1])) # 45
n3 = round(mean(data$price1[data$Period==20])) # 40

data = fdatas
b2 = lm(price2 ~ Period,data = data[data$accept1==0,]) # second offer regression
clusters = cluster.vcov(b2, data[data$accept1==0,]$Subject)
b2c = coeftest(b2, clusters)
n4 = round(b2c[2,4],2) # p = 0.24

data = fdata
b3 = lm(accept1 ~ Period,data = data) # first acceptance regression
clusters = cluster.vcov(b3, cbind(data$Subject))
b3c = coeftest(b3, clusters)
n5 = round(b3c[2,4],2)  # p = 0.44

data = fdata
b4 = lm(accept2 ~ Period,data = data[data$accept1==0,]) # second acceptance regression
clusters = cluster.vcov(b4, data[data$accept1==0,]$Subject)
b4c = coeftest(b4, clusters)
n6 = round(b4c[2,4],2) # p = 0.9

data = fdata
b5 = lm(Profit ~ Period,data = data) # buyers surplus
clusters = cluster.vcov(b5, data$Subject)
b5c = coeftest(b5, clusters)
n7 = round(b5c[2,4],2) # p = 0.03

data = fdata[fdata$Profit>=0,]
b6 = lm(Profit ~ Period,data = data) # buyers surplus removing negative profits
clusters = cluster.vcov(b6, data$Subject)
b6c = coeftest(b6, clusters)
n8 = round(b6c[2,4],2) # p = 0.15

data = fdatas
b7 = lm(Profit ~ Period,data = data) # seller's profit
clusters = cluster.vcov(b7, data$Subject)
b7c = coeftest(b7, clusters)
n9 = round(b7c[2,4],2)  # p = 0.84

txt14 = sprintf("We observed a slight decrease in first offers across 20 periods (p = %g, OLS fit, s.e. clustered at the subject level): the first offer decreased from an average of %g in period 1, to %g in period 20. There was no significant overall linear change for the second offer (p = %g, OLS fit, s.e. clustered at the subject level). We did not observe any change in the acceptance rate over the course of 20 periods (p = %g for the first offer, p = %g  for the second offer, OLS fit, s.e. clustered at the subject level). Finally, the profit distribution, compared to the equilibrium prediction, was shifted towards buyers: they earned 18.3 per period on average (vs 16.3 predicted by the theory), while sellers earned 19.4 (vs predicted 22.4) (Table B1). Across 20 periods, there was a significant increase in buyers’ surplus (p = %g, OLS fit, s.e. clustered at the subject level), but no change in sellers’ profits (p = %g, OLS fit, s.e. clustered at the subject level). The change in buyers’ surplus was weaker and not statistically significant (p = %g, OLS fit, s.e. clustered at the subject level) when we excluded periods with a negative surplus (buyers accepting price offers higher than their value, which typically happened in the first periods of the experiment).", n1, n2, n3, n4, n5, n6, n7, n9, n8)



# FIGURE A6
load('data/bargaining1.RData')

# a
data = fdata2
cplot(data$Period,data$accept, cluster = data$Subject,
      ylim = c(0,1), xlab = 'period', ylab = 'second offer', hline = mean(data$accept),
      pch = 16, lwd = 2, pdf.name = 'output/figures/figureA6a.pdf', width=3.6, height=3.4)

# b
data = fdata2
cplot(data$Period,data$price2, cluster = data$Subject,
      ylim = c(10,60), xlab = 'period', ylab = 'second offer', hline = mean(data$price2),
      pch = 16, lwd = 2, pdf.name = 'output/figures/figureA6b.pdf', width=3.6, height=3.4)

# с
data = fdata2
cplot(data$Period,data$Profit, cluster = data$Subject,
      ylim = c(10,30), xlab = 'period', ylab = 'profit', hline = mean(data$Profit),
      pch = 16, lwd = 2, pdf.name = 'output/figures/figureA6c.pdf', width=3.6, height=3.4)

##############################################
# APPENDIX B
##############################################

# TABLE B1 + caption

# Live experiment
load('data/bargaining2.RData')

# first price offer
price1t = tapply(fdatas$price1,list(fdatas$condition,fdatas$Subject),mean,na.rm = T)
price1 = round(rowMeans(price1t,na.rm = T),1)
se_price1 = round(apply(price1t,1,se),1)

mprice1t = tapply(fdatas$price1,fdatas$Subject,mean,na.rm = T)
mprice1 = round(mean(mprice1t,na.rm = T),1)
mse_price1 = round(se(mprice1t),1)

n1 = mprice1
n2 = abs(round(t.test(mprice1t,mu = 45)$statistic,2))
n3 = abs(round(t.test(mprice1t,mu = 45)$p.value,2))

n13 = round(mean(price1t[1,],na.rm = T),1)
n14 = round(mean(price1t[3,],na.rm = T),1)
n15 = round(wilcox.test(price1t[1,],price1t[3,])$p.value,2) # p = 0.52

# second price offer
price2t = tapply(fdatas[fdatas$accept1==0,]$price2,list(fdatas[fdatas$accept1==0,]$condition,fdatas[fdatas$accept1==0,]$Subject),mean,na.rm = T)
price2 = round(rowMeans(price2t,na.rm = T),1)
se_price2 = round(apply(price2t,1,se),1)

mprice2t = tapply(fdatas[fdatas$accept1==0,]$price2,fdatas[fdatas$accept1==0,]$Subject,mean,na.rm = T)
mprice2 = round(mean(mprice2t,na.rm = T),1)
mse_price2 = round(se(mprice2t),1)

n4 = mprice2
n5 = abs(round(t.test(mprice2t,mu = 37.5)$statistic,2))
n6 = abs(round(t.test(mprice2t,mu = 37.5)$p.value,2))

# first offer acceptance rate
accept1t = tapply(fdata$accept1,list(fdata$condition,fdata$Subject),mean,na.rm = T)
accept1 = round(100*rowMeans(accept1t,na.rm = T),1)
se_accept1 = round(100*apply(accept1t,1,se),1)

maccept1t = tapply(fdata$accept1,fdata$Subject,mean,na.rm = T)
maccept1 = round(100*mean(maccept1t,na.rm = T),1)
mse_accept1 = round(100*se(maccept1t),1)

n16 = round(100*mean(accept1t[1,],na.rm = T),1)
n17 = round(100*mean(accept1t[3,],na.rm = T),1)
n18 = round(wilcox.test(accept1t[1,],accept1t[3,])$p.value,2) # p = 0.75

# easy rejections
fdata$easy = as.numeric(fdata$price1>fdata$value)
easy1t = tapply(fdata[fdata$accept1==0,]$easy,list(fdata[fdata$accept1==0,]$condition,fdata[fdata$accept1==0,]$Subject),mean,na.rm = T)
easy1 = round(100*rowMeans(easy1t,na.rm = T),1)
se_easy1 = round(100*apply(easy1t,1,se),1)

measy1t = tapply(fdata[fdata$accept1==0,]$easy,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
measy1 = round(100*mean(measy1t,na.rm = T),1)
mse_easy1 = round(100*se(measy1t),1)

# second offer acceptance rate
accept2t = tapply(fdata[fdata$accept1==0,]$accept2,list(fdata[fdata$accept1==0,]$condition,fdata[fdata$accept1==0,]$Subject),mean,na.rm = T)
accept2 = round(100*rowMeans(accept2t,na.rm = T),1)
se_accept2 = round(100*apply(accept2t,1,se),1)

maccept2t = tapply(fdata[fdata$accept1==0,]$accept2,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
maccept2 = round(100*mean(maccept2t,na.rm = T),1)
mse_accept2 = round(100*se(maccept2t),1)

# buyer's profit
profit_bt = tapply(fdata$Profit,list(fdata$condition,fdata$Subject),mean,na.rm = T)
profit_b = round(rowMeans(profit_bt,na.rm = T),1)
se_profit_b = round(apply(profit_bt,1,se),1)

mprofit_bt = tapply(fdata$Profit,fdata$Subject,mean,na.rm = T)
mprofit_b = round(mean(mprofit_bt,na.rm = T),1)
mse_profit_b = round(se(mprofit_bt),1)

n19 = round(wilcox.test(profit_bt[1,],profit_bt[3,])$p.value,2) # p = 0.56

# seller's profit
profit_st = tapply(fdatas$Profit,list(fdatas$condition,fdatas$Subject),mean,na.rm = T)
profit_s = round(rowMeans(profit_st,na.rm = T),1)
se_profit_s = round(apply(profit_st,1,se),1)

mprofit_st = tapply(fdatas$Profit,fdatas$Subject,mean,na.rm = T)
mprofit_s = round(mean(mprofit_st,na.rm = T),1)
mse_profit_s = round(se(mprofit_st),1)

n20 = round(wilcox.test(profit_st[1,],profit_st[3,])$p.value,2) # p = 0.6

# seller's profit (rejections)
profit_st_rej = tapply(fdatas[fdatas$accept1==0,]$Profit,list(fdatas[fdatas$accept1==0,]$condition,fdatas[fdatas$accept1==0,]$Subject),mean,na.rm = T)
profit_s_rej = round(rowMeans(profit_st_rej,na.rm = T),1)
se_profit_s_rej = round(apply(profit_st_rej,1,se),1)

mprofit_st_rej = tapply(fdatas[fdatas$accept1==0,]$Profit,fdatas[fdatas$accept1==0,]$Subject,mean,na.rm = T)
mprofit_s_rej = round(mean(mprofit_st_rej,na.rm = T),1)
mse_profit_s_rej = round(se(mprofit_st_rej),1)

# buyer's first rt (all)
rt1_bt = tapply(fdata$rt1,list(fdata$condition,fdata$Subject),mean,na.rm = T)
rt1_b = round(rowMeans(rt1_bt,na.rm = T),1)
se_rt1_b = round(apply(rt1_bt,1,se),2)

mrt1_bt = tapply(fdata$rt1,fdata$Subject,mean,na.rm = T)
mrt1_b = round(mean(mrt1_bt,na.rm = T),1)
mse_rt1_b = round(se(mrt1_bt),2)

# buyer's first rt (rejection)
rt1_bt_rej = tapply(fdata[fdata$accept1==0,]$rt1,list(fdata[fdata$accept1==0,]$condition,fdata[fdata$accept1==0,]$Subject),mean,na.rm = T)
rt1_b_rej = round(rowMeans(rt1_bt_rej,na.rm = T),1)
se_rt1_b_rej = round(apply(rt1_bt_rej,1,se),2)

mrt1_bt_rej = tapply(fdata[fdata$accept1==0,]$rt1,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
mrt1_b_rej = round(mean(mrt1_bt_rej,na.rm = T),1)
mse_rt1_b_rej = round(se(mrt1_bt_rej),2)

# buyer's first rt (acceptance)
rt1_bt_acc = tapply(fdata[fdata$accept1==1,]$rt1,list(fdata[fdata$accept1==1,]$condition,fdata[fdata$accept1==1,]$Subject),mean,na.rm = T)
rt1_b_acc = round(rowMeans(rt1_bt_acc,na.rm = T),1)
se_rt1_b_acc = round(apply(rt1_bt_acc,1,se),2)

mrt1_bt_acc = tapply(fdata[fdata$accept1==1,]$rt1,fdata[fdata$accept1==1,]$Subject,mean,na.rm = T)
mrt1_b_acc = round(mean(mrt1_bt_acc,na.rm = T),1)
mse_rt1_b_acc = round(se(mrt1_bt_acc),2)

# buyer's first RT (easy)
fdata$easy = as.numeric(fdata$price1>fdata$value)
rt1_bet = tapply(fdata[fdata$easy==1,]$rt1,list(fdata[fdata$easy==1,]$condition,fdata[fdata$easy==1,]$Subject),mean,na.rm = T)
rt1_be = round(rowMeans(rt1_bet,na.rm = T),1)
se_rt1_be = round(apply(rt1_bet,1,se),2)

mrt1_bet = tapply(fdata[fdata$easy==1,]$rt1,fdata[fdata$easy==1,]$Subject,mean,na.rm = T)
mrt1_be = round(mean(mrt1_bet,na.rm = T),1)
mse_rt1_be = round(se(mrt1_bet),2)

# buyer's second rt (all)
fdata = fdata[fdata$rt2 > 0, ]
rt2_bt = tapply(fdata[fdata$accept1==0,]$rt2,list(fdata[fdata$accept1==0,]$condition,fdata[fdata$accept1==0,]$Subject),mean,na.rm = T)
rt2_b = round(rowMeans(rt2_bt,na.rm = T),1)
se_rt2_b = round(apply(rt2_bt,1,se),2)

mrt2_bt = tapply(fdata[fdata$accept1==0,]$rt2,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
mrt2_b = round(mean(mrt2_bt,na.rm = T),1)
mse_rt2_b = round(se(mrt2_bt),2)


tableB1a = rbind(price1,se_price1,
                 price2,se_price2,
                 accept1,se_accept1,
                 easy1,se_easy1,
                 accept2,se_accept2,
                 profit_b,se_profit_b,
                 profit_s,se_profit_s,
                 profit_s_rej,se_profit_s_rej,
                 rt1_b, se_rt1_b,
                 rt1_b_rej, se_rt1_b_rej,
                 rt1_b_acc, se_rt1_b_acc,
                 rt1_be, se_rt1_be,
                 rt2_b, se_rt2_b
)

tableB1b = rbind(mprice1,mse_price1,
                 mprice2,mse_price2,
                 maccept1,mse_accept1,
                 measy1,mse_easy1,
                 maccept2,mse_accept2,
                 mprofit_b,mse_profit_b,
                 mprofit_s,mse_profit_s,
                 mprofit_s_rej,mse_profit_s_rej,
                 mrt1_b, mse_rt1_b,
                 mrt1_b_rej, mse_rt1_b_rej,
                 mrt1_b_acc, mse_rt1_b_acc,
                 mrt1_be, mse_rt1_be,
                 mrt2_b, mse_rt2_b
)


# Explicit experiment
load('data/bargaining1.RData')

# first price offer
mprice1t = tapply(fdatas$price1,fdatas$Subject,mean,na.rm = T)
mprice1 = round(mean(mprice1t,na.rm = T),1)
mse_price1 = round(se(mprice1t),1)

n7 = mprice1
n8 = abs(round(t.test(mprice1t,mu = 45)$statistic,2))
n9 = abs(round(t.test(mprice1t,mu = 45)$p.value,2))

# second price offer
mprice2t = tapply(fdatas[fdatas$accept1==0,]$price2,fdatas[fdatas$accept1==0,]$Subject,mean,na.rm = T)
mprice2 = round(mean(mprice2t,na.rm = T),1)
mse_price2 = round(se(mprice2t),1)

n10 = mprice2
n11 = abs(round(t.test(mprice2t,mu = 37.5)$statistic,2))
n12 = abs(round(t.test(mprice2t,mu = 37.5)$p.value,2))


# first offer acceptance rate
maccept1t = tapply(fdata$accept1,fdata$Subject,mean,na.rm = T)
maccept1 = round(100*mean(maccept1t,na.rm = T),1)
mse_accept1 = round(100*se(maccept1t),1)

# easy rejections
fdata$easy = as.numeric(fdata$price1>fdata$value)
measy1t = tapply(fdata[fdata$accept1==0,]$easy,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
measy1 = round(100*mean(measy1t,na.rm = T),1)
mse_easy1 = round(100*se(measy1t),1)

# second offer acceptance rate
maccept2t = tapply(fdata[fdata$accept1==0,]$accept2,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
maccept2 = round(100*mean(maccept2t,na.rm = T),1)
mse_accept2 = round(100*se(maccept2t),1)

# buyer's profit
mprofit_bt = tapply(fdata$Profit,fdata$Subject,mean,na.rm = T)
mprofit_b = round(mean(mprofit_bt,na.rm = T),1)
mse_profit_b = round(se(mprofit_bt),1)

# seller's profit
mprofit_st = tapply(fdatas$Profit,fdatas$Subject,mean,na.rm = T)
mprofit_s = round(mean(mprofit_st,na.rm = T),1)
mse_profit_s = round(se(mprofit_st),1)

# seller's profit (rejections)
mprofit_st_rej = tapply(fdatas[fdatas$accept1==0,]$Profit,fdatas[fdatas$accept1==0,]$Subject,mean,na.rm = T)
mprofit_s_rej = round(mean(mprofit_st_rej,na.rm = T),1)
mse_profit_s_rej = round(se(mprofit_st_rej),1)

# buyer's first rt (all)
mrt1_bt = tapply(fdata$rt1,fdata$Subject,mean,na.rm = T)
mrt1_b = round(mean(mrt1_bt,na.rm = T),1)
mse_rt1_b = round(se(mrt1_bt),2)

# buyer's first rt (rejection)
mrt1_bt_rej = tapply(fdata[fdata$accept1==0,]$rt1,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
mrt1_b_rej = round(mean(mrt1_bt_rej,na.rm = T),1)
mse_rt1_b_rej = round(se(mrt1_bt_rej),2)

# buyer's first rt (acceptance)
mrt1_bt_acc = tapply(fdata[fdata$accept1==1,]$rt1,fdata[fdata$accept1==1,]$Subject,mean,na.rm = T)
mrt1_b_acc = round(mean(mrt1_bt_acc,na.rm = T),1)
mse_rt1_b_acc = round(se(mrt1_bt_acc),2)

# buyer's first RT (easy)
fdata$easy = as.numeric(fdata$price1>fdata$value)
mrt1_bet = tapply(fdata[fdata$easy==1,]$rt1,fdata[fdata$easy==1,]$Subject,mean,na.rm = T)
mrt1_be = round(mean(mrt1_bet,na.rm = T),1)
mse_rt1_be = round(se(mrt1_bet),2)

# buyer's second rt (all)
fdata = fdata[fdata$rt2 > 0, ]
mrt2_bt = tapply(fdata[fdata$accept1==0,]$rt2,fdata[fdata$accept1==0,]$Subject,mean,na.rm = T)
mrt2_b = round(mean(mrt2_bt,na.rm = T),1)
mse_rt2_b = round(se(mrt2_bt),2)

tableB1c = rbind(mprice1,mse_price1,
                 mprice2,mse_price2,
                 maccept1,mse_accept1,
                 measy1,mse_easy1,
                 maccept2,mse_accept2,
                 mprofit_b,mse_profit_b,
                 mprofit_s,mse_profit_s,
                 mprofit_s_rej,mse_profit_s_rej,
                 mrt1_b, mse_rt1_b,
                 mrt1_b_rej, mse_rt1_b_rej,
                 mrt1_b_acc, mse_rt1_b_acc,
                 mrt1_be, mse_rt1_be,
                 mrt2_b, mse_rt2_b
)


tableB1 = cbind(tableB1a,tableB1b,tableB1c)

write.csv(tableB1,file ='output/tables/tableB1.csv')

# caption extra
load('data/bargaining1.RData')
data = fdata2
b1 = lm(Profit ~ Period ,data = data) # second offer regression
clusters = cluster.vcov(b1, data$Subject)
b1c = coeftest(b1, clusters)
n21 = round(b1c[2,4],2) # p = 0.19

data = fdatas
b2 = lm(Profit ~ Period,data = data[data$accept1 == 0,]) # second offer regression
clusters = cluster.vcov(b2, data[data$accept1 == 0,]$Subject)
b2c = coeftest(b2, clusters)
n22 = round(b2c[2,4],2) # p = 0.41

data = fdatas[fdatas$accept1 == 0,]
prices_bargaining1 = tapply(data$price2,data$Subject,mean,na.rm = T)

data = fdata2
prices_selling1 = tapply(data$price2,data$Subject,mean,na.rm = T)

n23 = round(wilcox.test(prices_selling1,prices_bargaining1)$p.value,2) # p = 0.37


txt15 = sprintf("In the Live experiment, the average first price offer was %g ECU (lower than the equilibrium prediction of 45, t(44) = %g, p = %g) and the average second price was %g ECU (significantly lower than 37.5, t(44) = %g, p < 0.001). In the Explicit-RT experiment, the average first price offer was %g ECU (not significantly different from 45, t(32) = %g, p = %g), and the average second price was %g ECU (lower than 37.5, t(32) = %g, p < 0.001).", n1, n2, n3, n4, n5, n7, n8, n9, n10, n11)

txt16 = sprintf("Comparing Bargaining 1H and 1V, there was no significant difference between sellers’ first offers (%g vs. %g, p = %g, Wilcoxon rank sum test at the subject level), buyers’ acceptance rates (%g%% vs. %g%%, p = %g, Wilcoxon rank sum test at the subject level), or either player’s profits (p = %g, p = %g, Wilcoxon rank sum test at the subject level). ", n13, n14, n15, n16, n17, n18, n19, n20)

txt17 = sprintf("However, there was no significant increase in profits over the course of the selling task (p = %g, OLS fit, s.e. clustered at the subject level), or in the bargaining game, conditional on rejection (p = %g, OLS fit, s.e. clustered at the subject level). Another possibility is that subjects were making systematically higher or lower offers in the selling task (thus possibly earning higher profits). This was not the case: there was no significant difference in the average second-stage offers between the bargaining game and the selling task (p = %g, Wilcoxon rank-sum test at the subject level). ", n21, n22, n23)

# FIGURE B1

# a
load('data/bargaining2.RData')

data = fdatas[fdatas$visible == 0,]
par(mar=c(5,4.3,1,1)) 
h1 = data$price1
h2 = data[data$accept1 == 0,]$price2

hist(h1, 40,  col=csp[1], xlab="price offers", main = NA,xlim = c(0,80),ylim = c(0,.15),cex.lab = 1.5,freq = F
     ,ylab = 'density')
hist(h2,40,  col=csp[2], add=T,freq = F)
points(rep(45,201),0:200,col=cs[1],type = 'l',lwd = 2,lty = 2)
points(rep(37.5,201),0:200,col=cs[2],type = 'l',lwd = 2,lty = 2)
legend('topleft',legend = c('first offer','second offer'), pch = 15,col = c(cs[1],cs[2]),cex = 1.2,bty = 'n')

dev.copy2pdf(file = paste("output/figures/figureB1a.pdf",sep = ''),width=6, height=5) 

# b
load('data/bargaining2.RData')
data = fdata[fdata$visible == 0,]
cplot(data$value,data$accept1,cluster = data$Subject,
      bins = 10, cutoff = 10, color = cs[1], cex.lab = 1.1,
      xlab = 'value', ylab = 'P (offer accepted)',
      ylim = c(0,1))
temp = data[data$accept1 == 0,]
cplot(temp$value,temp$accept2,cluster = temp$Subject,
      bins = 10, cutoff = 10, add = T, color = cs[2],
      xlab = 'value', ylab = 'P (offer accepted)',pch = 18,
      ylim = c(0,1))
abline(h=0.5,col = 'black',lty = 2)
legend('topleft',legend = c('first offer','second offer'), pch = c(16,18),col = c(cs[1],cs[2]),cex = 1,bty = 'n')
dev.copy2pdf(file = paste("output/figures/figureB1b.pdf",sep = ''),width=4.32, height=3.6) 

# c
load('data/bargaining2.RData')
data = fdata  
data$surplus = data$value - data$price1
cplot(data$surplus,data$accept1,cluster = data$Subject, hline = 0.5,
      cutoff = 10, bins = 10, ceil = T, cex.lab = 1.1,
      xlab = "buyer's surplus", ylab = 'P (offer accepted)',width=4.32, height=3.6,
      ylim = c(0,1), pdf.name = 'output/figures/figureB1c.pdf')

# d
load('data/bargaining1.RData')
data = fdata  
data$surplus = data$value - data$price1
cplot(data$surplus,data$accept1,cluster = data$Subject, hline = 0.5,
      cutoff = 10, bins = 5, ceil = T, cex.lab = 1.1,
      xlab = "buyer's surplus", ylab = 'P (offer accepted)',width=4.32, height=3.6,
      ylim = c(0,1), pdf.name = 'output/figures/figureB1d.pdf')

# FIGURE B2

# a
load('data/bargaining1.RData')
data = fdata2
cplot(data$rt,data$price1-data$price2,cluster = data$Subject,
      bins = 1, color = cs[1],cutoff = 10, pch = 18,
      xlab = 'RT [s]', ylab = 'first offer - new offer',maxbin =8,
      ylim = c(0,30))
data = fdatas[fdatas$accept1 == 0,]
cplot(data$rtb,data$price1-data$price2,cluster = data$Subject, pch = 16, shift = 0.1,
      bins = 1, cutoff = 10, add = T, color = cs[5])
legend('topleft',legend = c('Selling 1H (explicit)','Bargaining 1H (explicit)'), pch = c(18,16),col = c(cs[1],cs[5]),cex = 1,bty = 'n')
dev.copy2pdf(file = paste("output/figures/figureB2a.pdf",sep = ''),width=5, height=4) 


# b
load('data/bargaining2.RData')
data = fdatas[fdatas$accept1==0 & fdatas$part == 1 & fdatas$visible==0,]

cplot(data$rtb,data$price2, bins = 1, cluster = data$Subject, 
      cutoff = 10, color = cs[5], ylim = c(20,50), 
      ylab = 'new offer', xlab = 'RT[s]')

data = fdatas[fdatas$accept1==0 & fdatas$part == 1 & fdatas$visible==1,]
cplot(data$rtb,data$price2, bins = 1, cluster = data$Subject, pch = 18, 
      cutoff = 10, color = cs[1], add = T, lty = 2)

legend("topleft",legend = c('Bargaining 1H (live)','Bargaining 1V (live)'),pch = 16, 
       col = c(cs[5],cs[1]),bty = 'n')

dev.copy2pdf(file = paste("output/figures/figureB2b.pdf",sep = ''),width=5, height=4) 


# TABLE B2
load('data/bargaining2.RData')

fdata$easy = as.numeric(fdata$price1>fdata$value)
fdata$value = fdata$value/100
fdata$price1 = fdata$price1/100

data = fdata[fdata$part==1 & fdata$visible==0,]
b1 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b1, cbind(data$Subject))
b1c = coeftest(b1, clusters)

data = fdata[fdata$part==1 & fdata$visible==1,]
b2 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b2, cbind(data$Subject))
b2c = coeftest(b2, clusters)

data = fdata[fdata$part==0 & fdata$visible==0,]
b3 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b3, cbind(data$Subject))
b3c = coeftest(b3, clusters)

data = fdata[ fdata$part==0 & fdata$visible==1,]
b4 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b4, cbind(data$Subject))
b4c = coeftest(b4, clusters)

data = fdata[fdata$part==1,]
b5 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible+easy,data = data)
clusters = cluster.vcov(b5, cbind(data$Subject))
b5c = coeftest(b5, clusters)

data = fdata[fdata$part==0,]
b6 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+value+easy+visible,data = data)
clusters = cluster.vcov(b6, cbind(data$Subject))
b6c = coeftest(b6, clusters)

data = fdata
data$part = 1 - data$part
b7 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible*part+easy,data = data)
clusters = cluster.vcov(b7, cbind(data$Subject))
b7c = coeftest(b7, clusters)

data = fdata[fdata$easy == 0,]
data$part = 1 - data$part
b8 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible + part,data = data)
clusters = cluster.vcov(b8, cbind(data$Subject))
b8c = coeftest(b8, clusters)

data = fdata[fdata$easy == 1,]
data$part = 1 - data$part
b9 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible + part,data = data)
clusters = cluster.vcov(b9, cbind(data$Subject))
b9c = coeftest(b9, clusters)

htmlreg(list(b1,b2,b3,b4,b5,b6,b7,b8,b9),file = "output/tables/tableB2.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2],b5c[,2],b6c[,2],b7c[,2],b8c[,2],b9c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4],b5c[,4],b6c[,4],b7c[,4],b8c[,4],b9c[,4]),
        include.adjrs = F, digits = 3,
        custom.model.names = c('(1)','(2)','(3)','(4)','(5)','(6)','(7)','(8)','(9)'))

# TABLE B3
load('data/bargaining1.RData')
data = fdata
data$value = data$value/100
data$price1 = data$price1/100

data$easy = as.numeric(data$price1>data$value)

b1 = lm(log(rt1) ~ value*accept1+price1*accept1 + Period,data = data)
clusters = cluster.vcov(b1, cbind(data$Subject))
b1c = coeftest(b1, clusters)

b2 = lm(log(rt1) ~ value*accept1 + price1*accept1 + Period +easy,data = data)
clusters = cluster.vcov(b2, cbind(data$Subject))
b2c = coeftest(b2, clusters)

b3 = lm(log(rt1) ~ value*accept1 + price1*accept1 + Period,data = data[data$easy == 0,])
clusters = cluster.vcov(b3, cbind(data[data$easy == 0,]$Subject))
b3c = coeftest(b3, clusters)

b4 = lm(log(rt1) ~ value*accept1 + price1*accept1 + Period,data = data[data$easy == 1,])
clusters = cluster.vcov(b4, cbind(data[data$easy == 1,]$Subject))
b4c = coeftest(b4, clusters)

htmlreg(list(b1,b2,b3,b4),file = "output/tables/tableB3.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4]),
        include.adjrs = F,
        custom.model.names = c('(1)','(2)','(3)','(4)'))

# TABLE B4: SECOND STAGE OFFERS
load('data/bargaining2.RData')
data = fdatas[fdatas$accept1==0 & fdatas$part==1 & fdatas$visible==0,]
b1 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b1, cbind(data$Subject))
b1c = coeftest(b1, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==1 & fdatas$visible==1,]
b2 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b2, cbind(data$Subject))
b2c = coeftest(b2, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==0 & fdatas$visible==0,]
b3 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b3, cbind(data$Subject))
b3c = coeftest(b3, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==0 & fdatas$visible==1,]
b4 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b4, cbind(data$Subject))
b4c = coeftest(b4, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==1 ,]
b5 = lm(price2 ~ rtb*visible+price1+Period,data = data)
clusters = cluster.vcov(b5, cbind(data$Subject))
b5c = coeftest(b5, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==0 ,]
b6 = lm(price2 ~ rtb*visible+price1+Period,data = data)
clusters = cluster.vcov(b6, cbind(data$Subject))
b6c = coeftest(b6, clusters)

htmlreg(list(b1,b2,b3,b4,b5,b6),file = "output/tables/tableB4.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2],b5c[,2],b6c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4],b5c[,4],b6c[,4]),
        include.adjrs = F,
        custom.model.names = c('(1)','(2)','(3)','(4)','(5)','(6)'))

# TABLE B5: NEW OFFER - SELLING TASK
load('data/bargaining2.RData')
fdata2 = fdata24[fdata24$part == 1,]
fdata4 = fdata24[fdata24$part == 0,]

fdata2 = fdata2[fdata2$reps==0,]
fdata4 = fdata4[fdata4$reps==0,]

data = fdata2[fdata2$visible == 0,]
b1 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b1, cbind(data$Subject))
b1c = coeftest(b1, clusters)

data = fdata2[fdata2$visible == 1,]
b2 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b2, cbind(data$Subject))
b2c = coeftest(b2, clusters)


data = fdata4[fdata4$visible == 0,]
b3 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b3, cbind(data$Subject))
b3c = coeftest(b3, clusters)


data = fdata4[fdata4$visible == 1,]
b4 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b4, cbind(data$Subject))
b4c = coeftest(b4, clusters)

htmlreg(list(b1,b2,b3,b4),file = "output/tables/tableB5.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4]),
        include.adjrs = F, digits = 3,
        custom.model.names = c('(1)','(2)','(3)','(4)'))


# TABLE B6: OFFERS - SELLING TASK
load('data/bargaining1.RData')
sellers = unique(fdatas[fdatas$type==1,]$Subject)
buyers = unique(fdata[fdata$type==2,]$Subject)

fdata2$type = 0
fdata2[fdata2$Subject %in% sellers,]$type = 1

data2 = fdata2

b1 = lm(price2~ rt ,data = data2)
clusters = cluster.vcov(b1, cbind(data2$Subject))
b1c = coeftest(b1, clusters)

b2 = lm(price2~ rt +price1,data = data2)
clusters = cluster.vcov(b2, cbind(data2$Subject))
b2c = coeftest(b2, clusters)

b3 = lm(price2~ rt +price1+Period,data = data2)
clusters = cluster.vcov(b3, cbind(data2$Subject))
b3c = coeftest(b3, clusters)

b4 = lm(price2~ rt +price1 + Period+type,data = data2)
clusters = cluster.vcov(b4, cbind(data2$Subject))
b4c = coeftest(b4, clusters)

b5 = lm(price2~ rt*type +price1+Period,data = data2)
clusters = cluster.vcov(b5, cbind(data2$Subject))
b5c = coeftest(b5, clusters)

htmlreg(list(b1,b2,b3,b4,b5),file = "output/tables/tableB6.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2],b5c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4],b5c[,4]),
        include.adjrs = F,
        custom.model.names = c('(1)','(2)','(3)','(4)','(5)'))

# TABLE B7 - BUYING TASK
load('data/bargaining1.RData')

data3 = fdata3

data3$pricedif = data3$price1left - data3$price1right 
data3$valuedif = data3$valueleft - data3$valueright 
data3$rtdif = data3$rtleft - data3$rtright

b1 = glm(choiceleft~valuedif+ rtdif+pricedif ,family = 'binomial',data = data3)
clusters = cluster.vcov(b1, cbind(data3$Subject))
b1c = coeftest(b1, clusters)

b2 = glm(choiceleft~valuedif+ rtdif+pricedif +Period,family = 'binomial',data = data3)
clusters = cluster.vcov(b2, cbind(data3$Subject))
b2c = coeftest(b2, clusters)

b3 = glm(choiceleft~valuedif+ pricedif*rtdif+Period,family = 'binomial',data = data3)
clusters = cluster.vcov(b3, cbind(data3$Subject))
b3c = coeftest(b3, clusters)

b4 = glm(choiceleft~ pricedif + valuedif*rtdif+Period,family = 'binomial',data = data3)
clusters = cluster.vcov(b4, cbind(data3$Subject))
b4c = coeftest(b4, clusters)


htmlreg(list(b1,b2,b3,b4),file = "output/tables/tableB7.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4]),
        include.adjrs = F, digits = 3,
        custom.model.names = c('(1)','(2)','(3)','(4)'))

##############################################
# APPENDIX C
##############################################

# TABLE C1
load('data/bargaining2.RData')

fdata$easy = as.numeric(fdata$price1>fdata$value)
fdata$value = fdata$value/100
fdata$price1 = fdata$price1/100

data = fdata[fdata$part==1 & fdata$visible==0,]
b1 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b1, cbind(data$SessionID,data$Subject))
b1c = coeftest(b1, clusters)

data = fdata[fdata$part==1 & fdata$visible==1,]
b2 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b2, cbind(data$SessionID,data$Subject))
b2c = coeftest(b2, clusters)

data = fdata[fdata$part==0 & fdata$visible==0,]
b3 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b3, cbind(data$SessionID,data$Subject))
b3c = coeftest(b3, clusters)

data = fdata[ fdata$part==0 & fdata$visible==1,]
b4 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+easy,data = data)
clusters = cluster.vcov(b4, cbind(data$SessionID,data$Subject))
b4c = coeftest(b4, clusters)

data = fdata[fdata$part==1,]
b5 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible+easy,data = data)
clusters = cluster.vcov(b5, cbind(data$SessionID,data$Subject))
b5c = coeftest(b5, clusters)

data = fdata[fdata$part==0,]
b6 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+value+easy+visible,data = data)
clusters = cluster.vcov(b6, cbind(data$SessionID,data$Subject))
b6c = coeftest(b6, clusters)

data = fdata
data$part = 1 - data$part
b7 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible*part+easy,data = data)
clusters = cluster.vcov(b7, cbind(data$SessionID,data$Subject))
b7c = coeftest(b7, clusters)

data = fdata[fdata$easy == 0,]
data$part = 1 - data$part
b8 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible + part,data = data)
clusters = cluster.vcov(b8, cbind(data$SessionID,data$Subject))
b8c = coeftest(b8, clusters)

data = fdata[fdata$easy == 1,]
data$part = 1 - data$part
b9 = lm(log(rt1) ~ value*accept1+price1*accept1+Period+visible + part,data = data)
clusters = cluster.vcov(b9, cbind(data$SessionID,data$Subject))
b9c = coeftest(b9, clusters)

htmlreg(list(b1,b2,b3,b4,b5,b6,b7,b8,b9),file = "output/tables/tableC1.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2],b5c[,2],b6c[,2],b7c[,2],b8c[,2],b9c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4],b5c[,4],b6c[,4],b7c[,4],b8c[,4],b9c[,4]),
        include.adjrs = F, digits = 3,
        custom.model.names = c('(1)','(2)','(3)','(4)','(5)','(6)','(7)','(8)','(9)'))

# TABLE C2
load('data/bargaining1.RData')
data = fdata
data$value = data$value/100
data$price1 = data$price1/100

data$easy = as.numeric(data$price1>data$value)

b1 = lm(log(rt1) ~ value*accept1+price1*accept1 + Period,data = data)
clusters = cluster.vcov(b1, cbind(data$SessionID,data$Subject))
b1c = coeftest(b1, clusters)

b2 = lm(log(rt1) ~ value*accept1 + price1*accept1 + Period +easy,data = data)
clusters = cluster.vcov(b2, cbind(data$SessionID,data$Subject))
b2c = coeftest(b2, clusters)

b3 = lm(log(rt1) ~ value*accept1 + price1*accept1 + Period,data = data[data$easy == 0,])
clusters = cluster.vcov(b3, cbind(data[data$easy == 0,]$SessionID,data[data$easy == 0,]$Subject))
b3c = coeftest(b3, clusters)

b4 = lm(log(rt1) ~ value*accept1 + price1*accept1 + Period,data = data[data$easy == 1,])
clusters = cluster.vcov(b4, cbind(data[data$easy == 1,]$SessionID,data[data$easy == 1,]$Subject))
b4c = coeftest(b4, clusters)

htmlreg(list(b1,b2,b3,b4),file = "output/tables/tableC2.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4]),
        include.adjrs = F,
        custom.model.names = c('(1)','(2)','(3)','(4)'))


# TABLE C3: SECOND STAGE OFFERS

load('data/bargaining2.RData')
data = fdatas[fdatas$accept1==0 & fdatas$part==1 & fdatas$visible==0,]
b1 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b1, cbind(data$SessionID,data$Subject))
b1c = coeftest(b1, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==1 & fdatas$visible==1,]
b2 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b2, cbind(data$SessionID,data$Subject))
b2c = coeftest(b2, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==0 & fdatas$visible==0,]
b3 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b3, cbind(data$SessionID,data$Subject))
b3c = coeftest(b3, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==0 & fdatas$visible==1,]
b4 = lm(price2 ~ rtb+price1+Period,data = data)
clusters = cluster.vcov(b4, cbind(data$SessionID,data$Subject))
b4c = coeftest(b4, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==1 ,]
b5 = lm(price2 ~ rtb*visible+price1+Period,data = data)
clusters = cluster.vcov(b5, cbind(data$SessionID,data$Subject))
b5c = coeftest(b5, clusters)

data = fdatas[fdatas$accept1==0 & fdatas$part==0 ,]
b6 = lm(price2 ~ rtb*visible+price1+Period,data = data)
clusters = cluster.vcov(b6, cbind(data$SessionID,data$Subject))
b6c = coeftest(b6, clusters)

htmlreg(list(b1,b2,b3,b4,b5,b6),file = "output/tables/tableC3.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2],b5c[,2],b6c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4],b5c[,4],b6c[,4]),
        include.adjrs = F,
        custom.model.names = c('(1)','(2)','(3)','(4)','(5)','(6)'))

# TABLE C4: NEW OFFER - SELLING TASK

load('data/bargaining2.RData')
fdata2 = fdata24[fdata24$part == 1,]
fdata4 = fdata24[fdata24$part == 0,]

fdata2 = fdata2[fdata2$reps==0,]
fdata4 = fdata4[fdata4$reps==0,]

data = fdata2[fdata2$visible == 0,]
b1 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b1, cbind(data$session,data$Subject))
b1c = coeftest(b1, clusters)

data = fdata2[fdata2$visible == 1,]
b2 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b2, cbind(data$session,data$Subject))
b2c = coeftest(b2, clusters)


data = fdata4[fdata4$visible == 0,]
b3 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b3, cbind(data$session,data$Subject))
b3c = coeftest(b3, clusters)


data = fdata4[fdata4$visible == 1,]
b4 = lm(price2~ rt+price1+Period,data = data)
clusters = cluster.vcov(b4, cbind(data$session,data$Subject))
b4c = coeftest(b4, clusters)

htmlreg(list(b1,b2,b3,b4),file = "output/tables/tableC4.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4]),
        include.adjrs = F, digits = 3,
        custom.model.names = c('(1)','(2)','(3)','(4)'))



# TABLE C5: OFFERS - SELLING TASK

load('data/bargaining1.RData')
sellers = unique(fdatas[fdatas$type==1,]$Subject)
buyers = unique(fdata[fdata$type==2,]$Subject)

fdata2$type = 0
fdata2[fdata2$Subject %in% sellers,]$type = 1

data2 = fdata2

b1 = lm(price2~ rt ,data = data2)
clusters = cluster.vcov(b1, cbind(data2$session,data2$Subject))
b1c = coeftest(b1, clusters)

b2 = lm(price2~ rt +price1,data = data2)
clusters = cluster.vcov(b2, cbind(data2$session,data2$Subject))
b2c = coeftest(b2, clusters)

b3 = lm(price2~ rt +price1+Period,data = data2)
clusters = cluster.vcov(b3, cbind(data2$session,data2$Subject))
b3c = coeftest(b3, clusters)

b4 = lm(price2~ rt +price1 + Period+type,data = data2)
clusters = cluster.vcov(b4, cbind(data2$session,data2$Subject))
b4c = coeftest(b4, clusters)

b5 = lm(price2~ rt*type +price1+Period,data = data2)
clusters = cluster.vcov(b5, cbind(data2$session,data2$Subject))
b5c = coeftest(b5, clusters)

htmlreg(list(b1,b2,b3,b4,b5),file = "output/tables/tableC5.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2],b5c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4],b5c[,4]),
        include.adjrs = F,
        custom.model.names = c('(1)','(2)','(3)','(4)','(5)'))

# TABLE C6 - BUYING TASK
load('data/bargaining1.RData')

data3 = fdata3

data3$pricedif = data3$price1left - data3$price1right 
data3$valuedif = data3$valueleft - data3$valueright 
data3$rtdif = data3$rtleft - data3$rtright

b1 = glm(choiceleft~valuedif+ rtdif+pricedif ,family = 'binomial',data = data3)
clusters = cluster.vcov(b1, cbind(data3$Subject,data3$SessionID))
b1c = coeftest(b1, clusters)

b2 = glm(choiceleft~valuedif+ rtdif+pricedif +Period,family = 'binomial',data = data3)
clusters = cluster.vcov(b2, cbind(data3$Subject,data3$SessionID))
b2c = coeftest(b2, clusters)

b3 = glm(choiceleft~valuedif+ pricedif*rtdif+Period,family = 'binomial',data = data3)
clusters = cluster.vcov(b3, cbind(data3$Subject,data3$SessionID))
b3c = coeftest(b3, clusters)

b4 = glm(choiceleft~ pricedif + valuedif*rtdif+Period,family = 'binomial',data = data3)
clusters = cluster.vcov(b4, cbind(data3$Subject,data3$SessionID))
b4c = coeftest(b4, clusters)


htmlreg(list(b1,b2,b3,b4),file = "output/tables/tableC6.html", 
        override.se = list(b1c[,2],b2c[,2],b3c[,2],b4c[,2]),
        override.pvalues = list(b1c[,4],b2c[,4],b3c[,4],b4c[,4]),
        include.adjrs = F, digits = 3,
        custom.model.names = c('(1)','(2)','(3)','(4)'))



#######################################################
# ALL TEXT
#######################################################

fileConn<-file("output/text/text_values.txt")
writeLines(c("MAIN TEXT \n",
             txt1,'\n',
             txt2,'\n',
             txt3,'\n',
             txt4,'\n',
             txt5,'\n',
             txt6,'\n',
             txt7,'\n',
             txt8,'\n',
             txt9,'\n',
             txt10,'\n',
             txt11,'\n',
             txt12,'\n',
             txt13,'\n',
             "APPENDICES \n",
             txt14,'\n',
             txt15,'\n',
             txt16,'\n',
             txt17,'\n'), fileConn)
close(fileConn)

