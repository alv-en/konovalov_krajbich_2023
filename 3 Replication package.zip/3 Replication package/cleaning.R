
##########################################
# EXPLICIT-RT experiment
##########################################

rm(list = ls())

s11 <- read.csv("data/raw/explicit/s1subjects1.csv")
s12 <- read.csv("data/raw/explicit/s1subjects2.csv")
s13 <- read.csv("data/raw/explicit/s1subjects3.csv")
s11$session = 1
s12$session = 1
s13$session = 1

s21 <- read.csv("data/raw/explicit/s2subjects1.csv")
s22 <- read.csv("data/raw/explicit/s2subjects2.csv")
s23 <- read.csv("data/raw/explicit/s2subjects3.csv")

s21$session = 2
s22$session = 2
s23$session = 2

s31 <- read.csv("data/raw/explicit/s3subjects1.csv")
s32 <- read.csv("data/raw/explicit/s3subjects2.csv")
s33 <- read.csv("data/raw/explicit/s3subjects3.csv")


s31$session = 3
s32$session = 3
s33$session = 3


s41 <- read.csv("data/raw/explicit/s4subjects1.csv")
s42 <- read.csv("data/raw/explicit/s4subjects2.csv")
s43 <- read.csv("data/raw/explicit/s4subjects3.csv")

s41$session = 4
s42$session = 4
s43$session = 4


data = rbind (s11,s21,s31,s41)
data$Subject = data$Subject + 100*data$session

data2 = rbind (s12,s22,s32,s42)
data2$Subject = data2$Subject + 100*data2$session

data3 = rbind (s13,s23,s33,s43)
data3$Subject = data3$Subject + 100*data3$session

# cleaning data

data = data[data$Period >=1,] # removing practice

datas = data[data$type==1,]
data = data[data$type==2,]

data = data[data$decision1 ==1,]  # removing no decision for buyer in stage 1


data2 = data2[data2$Period >=1,] # removing practice

data$code = data$session*1000 + data$Group*100 + data$Period
datas$code =  datas$session*1000 + datas$Group*100 + datas$Period
datas$rtb = 0
for (i in unique(data$code)){
  datas[datas$code==i,]$value = data[data$code==i,]$value
  datas[datas$code==i,]$rtb = data[data$code==i,]$rt1
}

datas = datas[datas$code %in% unique(data$code),]  # removing sellers trials where buyers made no decision in the first offer

data3 = data3[data3$Period >=1,] # removing practice

# excluding repeated trials in part 2

data2$reps = 0
for (i in unique(data2$Subject)){
  temp = data2[data2$Subject==i,]
  temp$question = temp$rt*1000000 + temp$price1
  temp$appear = 0
  for (j in unique(temp$question)){
    tt = temp[temp$question==j,]
    n1 = min(tt$Period)
    n2 = max(tt$Period)
    temp[temp$question == j & temp$Period == n2,]$appear = 1
    temp[temp$question == j & temp$Period == n1,]$appear = 0
    
  }
  data2[data2$Subject==i,]$reps = temp$appear
}


data3$reps = 0
for (i in unique(data3$Subject)){
  temp = data3[data3$Subject==i,]
  
  temp$question = paste(temp$rt, temp$value,temp$price1,temp$price2) 
  temp$appear = 0
  for (j in unique(temp$question)){
    tt = temp[temp$question==j,]
    
    totalreps = nrow(tt)
    if(totalreps == 6) {print(totalreps)}
    
    if (totalreps == 2){
      rep.periods = tt$Period[2]
      temp[temp$question == j & temp$Period %in% rep.periods,]$appear = 1
    } else if (totalreps > 2){
      rep.periods = tt$Period[2:totalreps]
      temp[temp$question == j & temp$Period %in% rep.periods,]$appear = 1
    }
   
  }
  data3[data3$Subject==i,]$reps = temp$appear
}

fdata = data
fdatas = datas

fdata2 = data2
fdata3 = data3

#save(fdata,fdatas,fdata2,fdata3,file = 'bargaining1.RData')


##########################################
# LIVE experiment
##########################################
rm(list = ls())

s11 <- read.csv("data/raw/live/s1subjects1.csv")
s12 <- read.csv("data/raw/live/s1subjects2.csv")
s13 <- read.csv("data/raw/live/s1subjects3.csv")
s14 <- read.csv("data/raw/live/s1subjects4.csv")
s11$session = 1
s12$session = 1
s13$session = 1
s14$session = 1

s11$part = 1
s13$part = 0

s11$visible = 1
s13$visible = 0

s12$visible = 1
s14$visible = 0

# 
s21 <- read.csv("data/raw/live/s2subjects1.csv")
s22 <- read.csv("data/raw/live/s2subjects2.csv")
s23 <- read.csv("data/raw/live/s2subjects3.csv")
s24a <- read.csv("data/raw/live/s2subjects4a.csv")
s24b <- read.csv("data/raw/live/s2subjects4b.csv")
s21$session = 2
s22$session = 2
s23$session = 2
s24a$session = 2
s24b$session = 2

s21$part = 1
s23$part = 0

s21$visible = 1
s23$visible = 0

s22$visible = 1
s24a$visible = 0
s24b$visible = 0
# 
s31 <- read.csv("data/raw/live/s3subjects1.csv")
s32 <- read.csv("data/raw/live/s3subjects2.csv")
s33 <- read.csv("data/raw/live/s3subjects3.csv")
s34a <- read.csv("data/raw/live/s3subjects4a.csv")
s34b <- read.csv("data/raw/live/s3subjects4b.csv")
s31$session = 3
s32$session = 3
s33$session = 3
s34a$session = 3
s34b$session = 3

s31$part = 1
s33$part = 0

s31$visible = 0
s33$visible = 1

s32$visible = 0
s34a$visible = 1
s34b$visible = 1
# 
# 
s41 <- read.csv("data/raw/live/s4subjects1.csv")
s42 <- read.csv("data/raw/live/s4subjects2.csv")
s43 <- read.csv("data/raw/live/s4subjects3.csv")
s44 <- read.csv("data/raw/live/s4subjects4.csv")
s41$session = 4
s42$session = 4
s43$session = 4
s44$session = 4

s41$part = 1
s43$part = 0

s41$visible = 0
s43$visible = 1

s42$visible = 0
s44$visible = 1


s51 <- read.csv("data/raw/live/s5subjects1.csv")
s52 <- read.csv("data/raw/live/s5subjects2.csv")
s53 <- read.csv("data/raw/live/s5subjects3.csv")
s54 <- read.csv("data/raw/live/s5subjects4.csv")
s51$session = 5
s52$session = 5
s53$session = 5
s54$session = 5

s51$part = 1
s53$part = 0

s51$visible = 0
s53$visible = 1

s52$visible = 0
s54$visible = 1


s61 <- read.csv("data/raw/live/s6subjects1.csv")
s62 <- read.csv("data/raw/live/s6subjects2.csv")
s63 <- read.csv("data/raw/live/s6subjects3.csv")
s64 <- read.csv("data/raw/live/s6subjects4.csv")
s61$session = 6
s62$session = 6
s63$session = 6
s64$session = 6

s61$part = 1
s63$part = 0

s61$visible = 1
s63$visible = 0

s62$visible = 1
s64$visible = 0

data = rbind (s11,s13,s21,s23,s31,s33,s41,s43,s51,s53,s61,s63)
data$Subject = data$Subject + 100*data$session

data2 = rbind (s12,s22,s32,s42,s52,s62)
data2$Subject = data2$Subject + 100*data2$session

s14t = s14[,c(4,5,7,23:26,28,45,46)]
s24at = s24a[,c(4,5,7,23:26,28,44,45)]
s24bt = s24b[,c(4,5,7,23:26,28,45,46)]
s34at = s34a[,c(4,5,7,23:26,28,44,45)]
s34bt = s34b[,c(4,5,7,23:26,28,45,46)]
s44t = s44[,c(4,5,7,23:26,28,33,34)]
s54t = s54[,c(4,5,7,23:26,28,33,34)]
s64t = s64[,c(4,5,7,23:26,28,33,34)]

data4 = rbind (s14t,s24at,s24bt,s34at,s34bt,s44t,s54t,s64t)
data4$Subject = data4$Subject + 100*data4$session



# cleaning data

data = data[data$Period >=1,] # removing practice

datas = data[data$type==1,]
data = data[data$type==2,]



data2 = data2[data2$Period >=1,] # removing practice

data$code = data$session*100000 + data$Group*1000 + data$part*100 + data$Period
datas$code =  datas$session*100000 + datas$Group*1000 + datas$part*100 + datas$Period
datas$rtb = 0
for (i in unique(data$code)){
  datas[datas$code==i,]$value = data[data$code==i,]$value
  datas[datas$code==i,]$rtb = data[data$code==i,]$rt1
}

# didn't make decisions in stage 1
temp = data[data$decision1 ==0,]
excluded = unique(temp$code)

data = data[data$decision1 ==1,]  # removing no decision for buyer in stage 1
datas = datas[!datas$code %in% excluded,]  # removing sellers trials where buyers made no decision in the first offer


data$visiblefirst = 0
data[data$session<=2 | data$session ==6,]$visiblefirst =1

datas$visiblefirst = 0
datas[datas$session<=2 | datas$session ==6,]$visiblefirst =1

data4 = data4[data4$Period >=1,] # removing practice


data4$visiblefirst = as.numeric(data4$session<=2)

data2$visiblefirst = as.numeric(data2$session<=2)


data2 = data2[,c(c(4,5,7,23:26,28,34,35,36))]

data2$part = 1
data4$part = 0

# excluding repeated trials in parts 2 and 4

data2$reps = 0
for (i in unique(data2$Subject)){
  temp = data2[data2$Subject==i,]
  temp$question = temp$rt*1000000 + temp$price1
  temp$appear = 0
  for (j in unique(temp$question)){
    tt = temp[temp$question==j,]
    n1 = min(tt$Period)
    n2 = max(tt$Period)
    temp[temp$question == j & temp$Period == n2,]$appear = 1
    temp[temp$question == j & temp$Period == n1,]$appear = 0
    
  }
  data2[data2$Subject==i,]$reps = temp$appear
}

data4$reps = 0
for (i in unique(data4$Subject)){
  temp = data4[data4$Subject==i,]
  temp$question = temp$rt*1000000 + temp$price1
  temp$appear = 0
  for (j in unique(temp$question)){
    tt = temp[temp$question==j,]
    n1 = min(tt$Period)
    n2 = max(tt$Period)
    temp[temp$question == j & temp$Period == n2,]$appear = 1
    temp[temp$question == j & temp$Period == n1,]$appear = 0
    
  }
  data4[data4$Subject==i,]$reps = temp$appear
}


data24 = rbind(data2,data4)

fdata = data
fdatas = datas
fdata2 = data2
fdata4 = data4
fdata24 = data24


fdatas$condition = 0
fdatas[fdatas$part==1 & fdatas$visible==0,]$condition = 1
fdatas[fdatas$part==0 & fdatas$visible==1,]$condition = 2
fdatas[fdatas$part==1 & fdatas$visible==1,]$condition = 3
fdatas[fdatas$part==0 & fdatas$visible==0,]$condition = 4


fdata$condition = 0
fdata[fdata$part==1 & fdata$visible==0,]$condition = 1
fdata[fdata$part==0 & fdata$visible==1,]$condition = 2
fdata[fdata$part==1 & fdata$visible==1,]$condition = 3
fdata[fdata$part==0 & fdata$visible==0,]$condition = 4

#save(fdata,fdatas,fdata24,file = 'bargaining2.RData')
